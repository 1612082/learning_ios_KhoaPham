
Project cuối kỳ
Tên: Nguyễn Hồng Đăng
Trung tâm tin học Khoa Phạm - khoá 27/11

Trong file này gồm có 4 mục:
1. Database:chứa file backupdb.backup trong file này chứa dữ liệu của chương trình được lưu bẵng pgAdmin4
2. Server: chứa dữ liệu tạo server được viết bằng nodejs-express
3. Client: chứa project xcode
4. Document: chứa file mô tả và hướng dẫn sử dụng và link demo chương trình hoàn chỉnh.

Link demo YouTube: https://www.youtube.com/watch?v=Ab64MJtkYBU&t=53s