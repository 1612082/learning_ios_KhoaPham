//
//  declareVariableGlobal.swift
//  waiterHelper
//
//  Created by HongDang on 2/20/20.
//  Copyright © 2020 HongDang. All rights reserved.
//

import Foundation
import  UIKit

let Kitchen_Storyboard = UIStoryboard(name: "Kitchen", bundle: nil)
let Main_Storyboard = UIStoryboard(name: "Main", bundle: nil)
let Payment_Storyboard = UIStoryboard(name: "Payment", bundle: nil)
let Resevation_Storyboard = UIStoryboard(name: "Resevation", bundle: nil)


let Server = "http://localhost:3000/"
var idToScroll:Int = 0
