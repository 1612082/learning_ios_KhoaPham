//
//  TableModel.swift
//  waiterHelper
//
//  Created by HongDang on 2/21/20.
//  Copyright © 2020 HongDang. All rights reserved.
//

import Foundation
public struct Table:Codable{
    public var ID : String
    public var IDLOBBY : String
    public var NAME : String
    public var SIZE : String
    public var STATE : String
}
