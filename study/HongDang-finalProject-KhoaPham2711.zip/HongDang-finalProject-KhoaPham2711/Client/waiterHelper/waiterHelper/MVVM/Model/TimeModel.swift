//
//  TimeModel.swift
//  waiterHelper
//
//  Created by HongDang on 3/15/20.
//  Copyright © 2020 HongDang. All rights reserved.
//

import Foundation
public struct DATETIME {
    var date:Int
    var month:Int
    var year:Int
    var hour:Int
    var minute:Int
    var seconds:Int
}

